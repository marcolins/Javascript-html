# examples_validation_front

exemplos para validação de Login e Register.

### Onde foi ultlizado

CODAR 2, treinamento programar.com.vc.

data: 12/07/2020

### Pré-requisitos

You're going to need:

**Node.js, version 10 or newer**

**NPM Live-server**

### Installing

Npm way

```
cd examples_validation_front
```

```
npm install
```

```
live-server
```

acesse: http://127.0.0.1:8080/

### Screenshots

## Login
<img src="/assets/print01.png" alt="Login">

## Register
<img src="/assets/print02.png" alt="Register">